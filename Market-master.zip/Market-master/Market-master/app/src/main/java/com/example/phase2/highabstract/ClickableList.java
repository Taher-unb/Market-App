package com.example.phase2.highabstract;

public interface ClickableList {

    /**
     * Sets up the Clickable List in the Activity
     */
    void viewList();
}
