package com.example.phase2.admin_activities;

import java.io.Serializable;

public enum LimitType implements Serializable {
    WEEKLY_LIMIT,
    MAX_INCOMPLETE,
    MORE_LEND
}
